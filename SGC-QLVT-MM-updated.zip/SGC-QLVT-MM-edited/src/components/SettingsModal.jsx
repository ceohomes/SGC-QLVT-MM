import React, { useState, useEffect } from 'react'
import { X, Settings, Save, User, Clock } from 'lucide-react'
import { DEFAULT_PCU_DAYS } from '../constants'

export default function SettingsModal({ isOpen, settings, onClose, onSave, user }) {
  const [local, setLocal] = useState(settings)

  const canEdit = user?.role === 'admin' || user?.chucDanh === 'truong-nhom'

  useEffect(() => {
    if (isOpen) setLocal(settings)
  }, [isOpen, settings])

  useEffect(() => {
    const handleEsc = (e) => { if (e.key === 'Escape' && isOpen) onClose() }
    window.addEventListener('keydown', handleEsc)
    return () => window.removeEventListener('keydown', handleEsc)
  }, [isOpen, onClose])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 modal-backdrop bg-black/50">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-royal-200">
        <div className="bg-gradient-to-r from-royal-700 to-royal-500 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Settings className="w-5 h-5 text-white" />
            <h2 className="text-white font-black text-[18px]">Cài đặt hệ thống</h2>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center text-white/70 hover:text-white hover:bg-white/20 rounded-xl transition-all">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* PCU days */}
          <div>
            <label className="block text-[14px] font-bold text-royal-700 mb-1.5">
              <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" /> Số ngày PCU báo quá hạn (từ ngày gửi PCU)</span>
            </label>
            <div className="flex items-center gap-3">
              <input
                type="number"
                readOnly={!canEdit}
                value={local.pcuDays || DEFAULT_PCU_DAYS}
                onChange={e => setLocal(p => ({ ...p, pcuDays: parseInt(e.target.value) || DEFAULT_PCU_DAYS }))}
                min={1}
                max={365}
                className={`w-28 px-3 py-2.5 border rounded-xl text-[16px] outline-none transition-all text-center font-bold ${
                  canEdit 
                    ? "border-royal-200 focus:border-royal-400 focus:ring-2 focus:ring-royal-100" 
                    : "border-slate-200 bg-slate-50 text-slate-500 cursor-not-allowed"
                }`}
              />
              <span className="text-[16px] text-slate-500">ngày</span>
            </div>
            <p className="text-[14px] text-slate-400 mt-1">
              Sau {local.pcuDays || DEFAULT_PCU_DAYS} ngày từ khi gửi PCU mà chưa có ngày PCU trả, hệ thống sẽ đánh dấu "Quá hạn"
            </p>
          </div>

          <div className="bg-royal-50 rounded-xl p-4 text-[14px] text-royal-700 space-y-1 border border-royal-100">
            <p className="font-bold">📌 Logic trạng thái tự động:</p>
            <p>• <span className="font-semibold text-emerald-600">Đã xử lý</span>: Đã có ngày PCU trả</p>
            <p>• <span className="font-semibold text-rose-600">Quá hạn</span>: Đã gửi PCU nhưng chưa có ngày trả, vượt {local.pcuDays || DEFAULT_PCU_DAYS} ngày</p>
            <p>• <span className="font-semibold text-indigo-600">Chưa gửi cung ứng</span>: Chưa nhập Ngày gửi PCU</p>
            <p>• <span className="font-semibold text-amber-600">Chờ xử lý</span>: Đã nhập Ngày gửi PCU nhưng chưa Quá hạn và chưa Trả</p>
          </div>
          {!canEdit && (
            <div className="bg-amber-50 rounded-xl p-4 text-[14px] text-amber-700 border border-amber-200">
              <p className="font-bold mb-1 flex items-center gap-1.5">
                <span className="text-[14px]">⚠️</span> Lưu ý quyền hạn:
              </p>
              <p>Tài khoản của bạn ({user?.chucDanh === 'chuyen-vien' ? 'Chuyên viên' : (user?.chucDanh || 'Nhân viên')}) chỉ có quyền <strong>xem thông tin</strong> cấu hình. Chỉ <strong>Trưởng nhóm</strong> mới có thể thay đổi các thông số này.</p>
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-royal-100 bg-royal-50 flex justify-end gap-3">
          <button onClick={onClose} className="px-5 h-9 border border-slate-300 text-slate-600 rounded-xl font-semibold text-[16px] hover:bg-slate-100 transition-all">
            {canEdit ? 'Hủy' : 'Đóng'}
          </button>
          
          {canEdit && (
            <button
              onClick={() => { onSave(local); onClose(); }}
              className="flex items-center gap-2 px-5 h-9 bg-royal-500 text-white rounded-xl font-bold text-[16px] hover:bg-royal-600 transition-all active:scale-95"
            >
              <Save className="w-3.5 h-3.5" />
              Lưu cài đặt
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
