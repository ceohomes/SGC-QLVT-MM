import React from 'react'
import { Boxes, Plus, Download, Upload, Settings, Search, RefreshCw, ShieldCheck, Briefcase, ChevronDown } from 'lucide-react'

export default function Header({
  onAddNew, onExport, onImport, onOpenSettings,
  totalRows, filteredRows, searchGlobal, onSearchGlobal, onRefresh,
  branding, projects = [], selectedProjectId = 'ALL', onProjectChange,
  onOpenSidebar
}) {
  return (
    <header className="sticky top-0 z-50 shadow-md" style={{background:'linear-gradient(135deg,#1d4ed8 0%,#2563eb 45%,#3b82f6 100%)'}}>
      {/* Decorative highlight */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-8 right-16 w-64 h-32 rounded-full opacity-10" style={{background:'radial-gradient(ellipse,#fff,transparent)'}} />
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />
      </div>

      <div className="relative flex items-center h-20 px-0">
        {/* Logo wrapper for larger hover area as requested by user */}
        <div 
          onMouseEnter={onOpenSidebar}
          className="h-full flex items-center justify-center pl-4 pr-6 cursor-pointer group"
        >
          {/* Logo badge - Modern rounded style */}
          <div className={`h-[58px] ${branding?.logoUrl ? 'px-5' : 'w-[58px]'} bg-white rounded-2xl flex items-center justify-center shadow-[0_8px_25px_-5px_rgba(0,0,0,0.3)] border-2 border-white/40 z-10 shrink-0 overflow-hidden group-hover:scale-[1.02] group-active:scale-95 transition-all`}>
            {branding?.logoUrl ? (
              <img src={branding.logoUrl} alt="Logo" className="h-12 w-auto object-contain" />
            ) : (
              <div className="flex flex-col items-center justify-center">
                <Boxes className="w-8 h-8 text-[#0f58a7]" />
              </div>
            )}
          </div>
        </div>

        {/* Header content container */}
        <div className="flex-1 flex items-center gap-4 px-2 flex-wrap">
          {/* Title (hidden on small screens to save space) */}
          <div className="hidden lg:block shrink-0">
            <h1 className="text-white font-black text-2xl leading-tight tracking-tight drop-shadow-md uppercase">
              Chi tiết công việc
            </h1>
            <p className="text-blue-100/80 text-[12px] font-bold uppercase tracking-[0.2em] mt-0.5">
              Quản lý vật tư & MMTB
            </p>
          </div>

          {/* Divider */}
          <div className="hidden lg:block w-px h-10 bg-white/20 shrink-0 mx-2" />

          {/* Search */}
          <div className="flex-1 min-w-[160px] max-w-xs relative">
            <Search className="w-3.5 h-3.5 text-blue-300 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Tìm kiếm toàn bộ..."
              value={searchGlobal}
              onChange={e => onSearchGlobal(e.target.value)}
              className="w-full pr-3 h-[34px] bg-white/12 border border-white/22 rounded-lg text-white text-[14px] placeholder-blue-300/70 focus:bg-white/20 focus:border-white/45 transition-all outline-none"
              style={{paddingLeft:'2rem'}}
            />
          </div>

          {/* Import */}
          <label className="flex items-center gap-1.5 px-4 bg-white/12 border border-white/22 text-white rounded-lg font-bold text-[14px] hover:bg-white/25 transition-all cursor-pointer whitespace-nowrap shrink-0 shadow-sm active:scale-95" style={{height:'38px'}}>
            <Upload className="w-4 h-4" />
            Import Excel
            <input type="file" accept=".xlsx,.xls" onChange={onImport} className="hidden" />
          </label>

          {/* Export */}
          <button
            onClick={onExport}
            className="flex items-center gap-1.5 px-4 bg-white/12 border border-white/22 text-white rounded-lg font-bold text-[14px] hover:bg-white/25 transition-all active:scale-95 whitespace-nowrap shrink-0 shadow-sm"
            style={{height:'38px'}}
          >
            <Download className="w-4 h-4" />
            Xuất Excel
          </button>

          {/* Icon-only buttons */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onRefresh}
              title="Tính lại trạng thái"
              className="flex items-center justify-center w-[38px] h-[38px] bg-white/12 border border-white/22 text-white rounded-lg hover:bg-white/25 transition-all shadow-sm"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={onOpenSettings}
              title="Cài đặt"
              className="flex items-center justify-center w-[38px] h-[38px] bg-white/12 border border-white/22 text-white rounded-lg hover:bg-white/25 transition-all shadow-sm"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>

          {/* Project Selector */}
          <div className="flex items-center gap-2 px-4 h-[38px] bg-white/12 border border-white/22 rounded-lg text-white text-[13px] hover:bg-white/25 transition-all shrink-0 relative pr-8 shadow-sm">
            <Briefcase className="w-4 h-4 text-blue-300 shrink-0" />
            <select
              value={selectedProjectId}
              onChange={e => onProjectChange(e.target.value)}
              className="bg-transparent outline-none border-none text-white font-bold cursor-pointer max-w-[180px] z-10"
              style={{ WebkitAppearance: 'none' }}
            >
              <option value="ALL" className="text-slate-800 font-bold">Tất cả Dự án</option>
              {projects.map(p => (
                <option key={p.id} value={p.id} className="text-slate-800 font-medium">
                  {p.khoiVietTat ? `${p.khoiVietTat}. ${p.ten}` : p.ten}
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-blue-300 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Stats pills — pushed to the right */}
          <div className="hidden md:flex items-center gap-2 ml-auto shrink-0">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/12 border border-white/20 backdrop-blur-sm">
              <div className="text-center">
                <div className="text-white font-black text-xl leading-none tabular-nums">{totalRows}</div>
                <div className="text-blue-200 text-[11px] font-medium mt-0.5">Tổng dòng</div>
              </div>
              <div className="w-px h-7 bg-white/20 mx-1" />
              <div className="text-center">
                <div className="text-white font-black text-xl leading-none tabular-nums">{filteredRows}</div>
                <div className="text-blue-200 text-[11px] font-medium mt-0.5">Đang hiện</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom border shimmer */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
    </header>
  )
}
